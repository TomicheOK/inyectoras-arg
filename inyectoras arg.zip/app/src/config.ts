// =============================================================================
// Inyectoras Argentinas - Configuration
// =============================================================================
// Web profesional para empresa de inyección de plásticos y asistencia técnica
// =============================================================================

// -----------------------------------------------------------------------------
// Site Config
// -----------------------------------------------------------------------------
export interface SiteConfig {
  title: string;
  description: string;
  language: string;
  keywords: string;
  ogImage: string;
  canonical: string;
}

export const siteConfig: SiteConfig = {
  title: "Inyectoras Argentinas | Servicio Técnico Especializado",
  description: "Más de 20 años de experiencia en inyección de plásticos y asistencia técnica integral. Servicio para todo tipo de máquinas y procesos. Cotizá ahora.",
  language: "es",
  keywords: "inyección de plásticos, servicio técnico inyectoras, mantenimiento inyectoras, reparación inyectoras, asistencia técnica industrial, Argentina",
  ogImage: "/images/logo.png",
  canonical: "https://inyectorasargentinas.com",
};

// -----------------------------------------------------------------------------
// Navigation Config
// -----------------------------------------------------------------------------
export interface NavDropdownItem {
  name: string;
  href: string;
}

export interface NavLink {
  name: string;
  href: string;
  icon: string;
  dropdown?: NavDropdownItem[];
}

export interface NavigationConfig {
  brandName: string;
  brandSubname: string;
  tagline: string;
  navLinks: NavLink[];
  ctaButtonText: string;
}

export const navigationConfig: NavigationConfig = {
  brandName: "INYECTORAS",
  brandSubname: "Argentinas",
  tagline: "Asistencia Técnica Especializada",
  navLinks: [
    { name: "Inicio", href: "#inicio", icon: "Home" },
    { name: "Servicios", href: "#servicios", icon: "Settings" },
    { name: "Nosotros", href: "#nosotros", icon: "Users" },
    { name: "Proceso", href: "#proceso", icon: "Workflow" },
    { name: "Contacto", href: "#contacto", icon: "Mail" },
  ],
  ctaButtonText: "Solicitar Presupuesto",
};

// -----------------------------------------------------------------------------
// Preloader Config
// -----------------------------------------------------------------------------
export interface PreloaderConfig {
  brandName: string;
  brandSubname: string;
  yearText: string;
}

export const preloaderConfig: PreloaderConfig = {
  brandName: "INYECTORAS",
  brandSubname: "Argentinas",
  yearText: "Desde 2004",
};

// -----------------------------------------------------------------------------
// Hero Config
// -----------------------------------------------------------------------------
export interface HeroStat {
  value: number;
  suffix: string;
  label: string;
}

export interface HeroConfig {
  scriptText: string;
  mainTitle: string;
  ctaButtonText: string;
  ctaTarget: string;
  stats: HeroStat[];
  decorativeText: string;
  backgroundImage: string;
}

export const heroConfig: HeroConfig = {
  scriptText: "Asistencia Técnica Especializada",
  mainTitle: "Expertos en\nInyección de Plásticos",
  ctaButtonText: "Solicitar Servicio",
  ctaTarget: "#contacto",
  stats: [
    { value: 20, suffix: "+", label: "Años de Experiencia" },
    { value: 500, suffix: "+", label: "Proyectos Exitosos" },
    { value: 200, suffix: "+", label: "Clientes Satisfechos" },
  ],
  decorativeText: "SERVICIO TÉCNICO INDUSTRIAL",
  backgroundImage: "/images/hero-bg.jpg",
};

// -----------------------------------------------------------------------------
// Services Showcase Config (adapted from wine showcase)
// -----------------------------------------------------------------------------
export interface Service {
  id: string;
  name: string;
  subtitle: string;
  year: string;
  image: string;
  filter: string;
  glowColor: string;
  description: string;
  tastingNotes: string;
  alcohol: string;
  temperature: string;
  aging: string;
}

export interface ServiceFeature {
  icon: string;
  title: string;
  description: string;
}

export interface ServiceQuote {
  text: string;
  attribution: string;
  prefix: string;
}

export interface ServicesShowcaseConfig {
  scriptText: string;
  subtitle: string;
  mainTitle: string;
  services: Service[];
  features: ServiceFeature[];
  quote: ServiceQuote;
}

export const servicesShowcaseConfig: ServicesShowcaseConfig = {
  scriptText: "Soluciones Integrales",
  subtitle: "NUESTROS SERVICIOS",
  mainTitle: "Especialistas en Inyección de Plásticos",
  services: [
    {
      id: "inyeccion",
      name: "Inyección de Plásticos",
      subtitle: "Procesos de Alta Precisión",
      year: "SERVICIO",
      image: "/images/inyeccion.jpg",
      filter: "",
      glowColor: "bg-blue-900/20",
      description: "Servicio completo de inyección de plásticos con tecnología de última generación. Garantizamos piezas de alta calidad con tolerancias precisas.",
      tastingNotes: "Procesos optimizados",
      alcohol: "Todas las marcas",
      temperature: "Control térmico",
      aging: "Experiencia comprobada"
    },
    {
      id: "tecnico",
      name: "Asistencia Técnica",
      subtitle: "Soporte Integral 24/7",
      year: "SOPORTE",
      image: "/images/servicio-tecnico.jpg",
      filter: "brightness(1.1)",
      glowColor: "bg-slate-700/20",
      description: "Asistencia técnica integral para todo tipo de máquinas inyectoras. Respuesta rápida y soluciones efectivas para minimizar el tiempo de parada.",
      tastingNotes: "Diagnóstico preciso",
      alcohol: "Todas las marcas",
      temperature: "Rápida respuesta",
      aging: "Técnicos certificados"
    },
    {
      id: "mantenimiento",
      name: "Mantenimiento",
      subtitle: "Preventivo y Correctivo",
      year: "MANTENIMIENTO",
      image: "/images/mantenimiento.jpg",
      filter: "brightness(1.15)",
      glowColor: "bg-gray-700/20",
      description: "Planes de mantenimiento preventivo y correctivo para maximizar la vida útil de tus equipos y prevenir fallas inesperadas.",
      tastingNotes: "Planes personalizados",
      alcohol: "Contratos flexibles",
      temperature: "Visitas programadas",
      aging: "Reducción de costos"
    }
  ],
  features: [
    {
      icon: "Settings",
      title: "Tecnología Avanzada",
      description: "Equipamiento de última generación para diagnósticos precisos y reparaciones eficientes."
    },
    {
      icon: "Clock",
      title: "Respuesta Rápida",
      description: "Atención inmediata para urgencias. Minimizamos el tiempo de inactividad de tu producción."
    },
    {
      icon: "Award",
      title: "Garantía Asegurada",
      description: "Todos nuestros trabajos cuentan con garantía escrita. Tu tranquilidad es nuestra prioridad."
    },
    {
      icon: "Users",
      title: "Equipo Especializado",
      description: "Técnicos certificados con años de experiencia en la industria del plástico."
    }
  ],
  quote: {
    text: "La calidad no es un acto, es un hábito que cultivamos cada día en cada servicio.",
    attribution: "Equipo Inyectoras Argentinas",
    prefix: "Nuestro Compromiso",
  },
};

// -----------------------------------------------------------------------------
// Process Carousel Config (adapted from winery carousel)
// -----------------------------------------------------------------------------
export interface ProcessSlide {
  image: string;
  title: string;
  subtitle: string;
  area: string;
  unit: string;
  description: string;
}

export interface ProcessCarouselConfig {
  scriptText: string;
  subtitle: string;
  mainTitle: string;
  locationTag: string;
  slides: ProcessSlide[];
}

export const processCarouselConfig: ProcessCarouselConfig = {
  scriptText: "Cómo Trabajamos",
  subtitle: "NUESTRO PROCESO",
  mainTitle: "Metodología Profesional Garantizada",
  locationTag: "Cobertura Nacional - Argentina",
  slides: [
    {
      image: "/images/servicio-tecnico.jpg",
      title: "Diagnóstico",
      subtitle: "Evaluación Precisa",
      area: "01",
      unit: "PASO",
      description: "Realizamos un diagnóstico exhaustivo de tu equipo utilizando tecnología avanzada para identificar cada problema potencial."
    },
    {
      image: "/images/inyeccion.jpg",
      title: "Propuesta",
      subtitle: "Solución Personalizada",
      area: "02",
      unit: "PASO",
      description: "Elaboramos una propuesta detallada con el alcance del trabajo, tiempos y costos, sin sorpresas ni costos ocultos."
    },
    {
      image: "/images/mantenimiento.jpg",
      title: "Ejecución",
      subtitle: "Trabajo Profesional",
      area: "03",
      unit: "PASO",
      description: "Ejecutamos el servicio con los más altos estándares de calidad, utilizando repuestos originales y técnicas certificadas."
    },
    {
      image: "/images/equipo.jpg",
      title: "Seguimiento",
      subtitle: "Garantía y Soporte",
      area: "04",
      unit: "PASO",
      description: "Realizamos seguimiento post-servicio para asegurar el óptimo funcionamiento de tu equipo. Tu satisfacción es nuestra meta."
    }
  ],
};

// -----------------------------------------------------------------------------
// About Us Config (adapted from museum)
// -----------------------------------------------------------------------------
export interface TimelineEvent {
  year: string;
  event: string;
}

export interface AboutTabContent {
  title: string;
  description: string;
  highlight: string;
}

export interface AboutTab {
  id: string;
  name: string;
  icon: string;
  image: string;
  content: AboutTabContent;
}

export interface AboutQuote {
  prefix: string;
  text: string;
  attribution: string;
}

export interface AboutConfig {
  scriptText: string;
  subtitle: string;
  mainTitle: string;
  introText: string;
  timeline: TimelineEvent[];
  tabs: AboutTab[];
  openingHours: string;
  openingHoursLabel: string;
  ctaButtonText: string;
  yearBadge: string;
  yearBadgeLabel: string;
  quote: AboutQuote;
  founderPhotoAlt: string;
  founderPhoto: string;
}

export const aboutConfig: AboutConfig = {
  scriptText: "Conocenos",
  subtitle: "SOBRE NOSOTROS",
  mainTitle: "Más de 20 Años de Excelencia",
  introText: "Desde 2004, Inyectoras Argentinas se posiciona como líder en servicios de inyección de plásticos y asistencia técnica. Nuestra trayectoria está construida sobre bases sólidas: compromiso, calidad y relaciones duraderas con nuestros clientes.",
  timeline: [
    { year: "2004", event: "Fundación de Inyectoras Argentinas" },
    { year: "2008", event: "Expansión a cobertura nacional" },
    { year: "2012", event: "Certificación ISO en procesos" },
    { year: "2016", event: "Incorporación de tecnología 4.0" },
    { year: "2020", event: "+500 proyectos completados" },
    { year: "2024", event: "Líderes en el mercado argentino" },
  ],
  tabs: [
    {
      id: "mision",
      name: "Misión",
      icon: "Target",
      image: "/images/equipo.jpg",
      content: {
        title: "Nuestra Misión",
        description: "Proveer soluciones integrales de inyección de plásticos y asistencia técnica que superen las expectativas de nuestros clientes, contribuyendo al crecimiento de la industria argentina.",
        highlight: "Excelencia en cada servicio"
      }
    },
    {
      id: "vision",
      name: "Visión",
      icon: "Eye",
      image: "/images/automatizacion.jpg",
      content: {
        title: "Nuestra Visión",
        description: "Ser reconocidos como la empresa líder en servicios de inyección de plásticos en Argentina, destacada por la calidad, innovación y compromiso con nuestros clientes.",
        highlight: "Liderazgo industrial"
      }
    },
    {
      id: "valores",
      name: "Valores",
      icon: "Heart",
      image: "/images/fabrica.jpg",
      content: {
        title: "Nuestros Valores",
        description: "Integridad, compromiso, excelencia técnica, innovación continua y atención personalizada definen cada acción que emprendemos.",
        highlight: "Ética profesional"
      }
    }
  ],
  openingHours: "Lunes a Viernes: 8:00 - 18:00",
  openingHoursLabel: "Horario de Atención",
  ctaButtonText: "Conocer Más",
  yearBadge: "2004",
  yearBadgeLabel: "Fundados",
  quote: {
    prefix: "Nuestro Legado",
    text: "La confianza de nuestros clientes es nuestro mayor activo. Cada servicio es una oportunidad para demostrar por qué somos los mejores.",
    attribution: "Fundadores de Inyectoras Argentinas",
  },
  founderPhotoAlt: "Equipo Inyectoras Argentinas",
  founderPhoto: "/images/equipo.jpg",
};

// -----------------------------------------------------------------------------
// Testimonials & Additional Services Config (adapted from news)
// -----------------------------------------------------------------------------
export interface NewsArticle {
  id: number;
  image: string;
  title: string;
  excerpt: string;
  date: string;
  category: string;
}

export interface Testimonial {
  name: string;
  role: string;
  text: string;
  rating: number;
}

export interface StoryQuote {
  prefix: string;
  text: string;
  attribution: string;
}

export interface StoryTimelineItem {
  value: string;
  label: string;
}

export interface TestimonialsConfig {
  scriptText: string;
  subtitle: string;
  mainTitle: string;
  viewAllText: string;
  readMoreText: string;
  articles: NewsArticle[];
  testimonialsScriptText: string;
  testimonialsSubtitle: string;
  testimonialsMainTitle: string;
  testimonials: Testimonial[];
  storyScriptText: string;
  storySubtitle: string;
  storyTitle: string;
  storyParagraphs: string[];
  storyTimeline: StoryTimelineItem[];
  storyQuote: StoryQuote;
  storyImage: string;
  storyImageCaption: string;
}

export const testimonialsConfig: TestimonialsConfig = {
  scriptText: "Servicios Adicionales",
  subtitle: "SOLUCIONES COMPLETAS",
  mainTitle: "Más Servicios Para Tu Industria",
  viewAllText: "Ver Todos",
  readMoreText: "Ver Más",
  articles: [
    {
      id: 1,
      image: "/images/optimizacion.jpg",
      title: "Optimización de Procesos",
      excerpt: "Mejoramos la eficiencia de tu línea de producción con análisis detallados y ajustes precisos.",
      date: "Servicio Disponible",
      category: "Eficiencia"
    },
    {
      id: 2,
      image: "/images/capacitacion.jpg",
      title: "Capacitación Técnica",
      excerpt: "Formamos a tu equipo en el manejo y mantenimiento de equipos de inyección.",
      date: "Cursos Personalizados",
      category: "Formación"
    },
    {
      id: 3,
      image: "/images/automatizacion.jpg",
      title: "Automatización",
      excerpt: "Modernizamos tus procesos con las últimas tecnologías de automatización industrial.",
      date: "Tecnología 4.0",
      category: "Innovación"
    }
  ],
  testimonialsScriptText: "Testimonios",
  testimonialsSubtitle: "CLIENTES SATISFECHOS",
  testimonialsMainTitle: "Lo Que Dicen Nuestros Clientes",
  testimonials: [
    {
      name: "Martín Rodríguez",
      role: "Gerente de Planta - Plásticos Sur",
      text: "Inyectoras Argentinas nos ha acompañado por más de 10 años. Su servicio es impecable y la respuesta ante urgencias es inmediata.",
      rating: 5
    },
    {
      name: "Laura Gómez",
      role: "Directora de Operaciones - Induplast",
      text: "El conocimiento técnico de su equipo es excepcional. Han resuelto problemas que otras empresas no pudieron diagnosticar.",
      rating: 5
    },
    {
      name: "Carlos Benítez",
      role: "Dueño - Inyecciones del Oeste",
      text: "Profesionalismo, puntualidad y garantía. Los recomiendo sin dudar para cualquier servicio de inyección de plásticos.",
      rating: 5
    }
  ],
  storyScriptText: "Nuestra Historia",
  storySubtitle: "TRAYECTORIA",
  storyTitle: "Dos Décadas de Excelencia",
  storyParagraphs: [
    "Desde nuestros inicios en 2004, hemos crecido junto a la industria plástica argentina. Lo que comenzó como un pequeño taller de servicio técnico se ha transformado en una empresa líder con cobertura nacional.",
    "Nuestro secreto es simple: combinamos experiencia acumulada con tecnología de vanguardia. Cada miembro de nuestro equipo comparte la pasión por resolver problemas y optimizar procesos."
  ],
  storyTimeline: [
    { value: "20+", label: "Años de Experiencia" },
    { value: "500+", label: "Proyectos Completados" },
    { value: "200+", label: "Clientes Activos" },
    { value: "98%", label: "Satisfacción" }
  ],
  storyQuote: {
    prefix: "Compromiso",
    text: "Cada máquina que reparamos lleva nuestro sello de calidad. Esa es nuestra promesa.",
    attribution: "Equipo Técnico",
  },
  storyImage: "/images/fabrica.jpg",
  storyImageCaption: "Instalaciones industriales de última generación",
};

// -----------------------------------------------------------------------------
// Contact Form Config
// -----------------------------------------------------------------------------
export interface ContactInfoItem {
  icon: string;
  label: string;
  value: string;
  subtext: string;
}

export interface ContactFormFields {
  nameLabel: string;
  namePlaceholder: string;
  emailLabel: string;
  emailPlaceholder: string;
  phoneLabel: string;
  phonePlaceholder: string;
  visitDateLabel: string;
  visitorsLabel: string;
  visitorsOptions: string[];
  messageLabel: string;
  messagePlaceholder: string;
  submitText: string;
  submittingText: string;
  successMessage: string;
  errorMessage: string;
}

export interface ContactFormConfig {
  scriptText: string;
  subtitle: string;
  mainTitle: string;
  introText: string;
  contactInfoTitle: string;
  contactInfo: ContactInfoItem[];
  form: ContactFormFields;
  privacyNotice: string;
  formEndpoint: string;
}

export const contactFormConfig: ContactFormConfig = {
  scriptText: "Contactanos",
  subtitle: "SOLICITÁ TU PRESUPUESTO",
  mainTitle: "Hablemos de Tu Proyecto",
  introText: "Completá el formulario y un especialista se contactará en menos de 24 horas. Atención personalizada para cada necesidad.",
  contactInfoTitle: "Información de Contacto",
  contactInfo: [
    {
      icon: "Phone",
      label: "Teléfono",
      value: "+54 11 4567-8900",
      subtext: "Lunes a Viernes 8:00 - 18:00"
    },
    {
      icon: "Mail",
      label: "Email",
      value: "info@inyectorasargentinas.com",
      subtext: "Respondemos en 24hs"
    },
    {
      icon: "MapPin",
      label: "Ubicación",
      value: "Buenos Aires, Argentina",
      subtext: "Cobertura Nacional"
    },
    {
      icon: "Clock",
      label: "Urgencias",
      value: "+54 11 4567-8901",
      subtext: "Servicio 24/7"
    }
  ],
  form: {
    nameLabel: "Nombre y Apellido",
    namePlaceholder: "Ingresá tu nombre completo",
    emailLabel: "Email",
    emailPlaceholder: "tu@email.com",
    phoneLabel: "Teléfono",
    phonePlaceholder: "+54 11 1234-5678",
    visitDateLabel: "Fecha preferida de visita",
    visitorsLabel: "Tipo de Servicio",
    visitorsOptions: ["Inyección de Plásticos", "Asistencia Técnica", "Reparación", "Mantenimiento", "Optimización", "Capacitación", "Otro"],
    messageLabel: "Mensaje",
    messagePlaceholder: "Contanos sobre tu proyecto o necesidad específica...",
    submitText: "Solicitar Presupuesto",
    submittingText: "Enviando...",
    successMessage: "¡Gracias! Tu consulta fue enviada. Nos contactaremos en menos de 24 horas.",
    errorMessage: "Hubo un error al enviar. Por favor, intentá nuevamente o contactanos por teléfono."
  },
  privacyNotice: "Al enviar este formulario, aceptás nuestra política de privacidad. Tus datos están protegidos.",
  formEndpoint: "https://formspree.io/f/YOUR_FORM_ID",
};

// -----------------------------------------------------------------------------
// Footer Config
// -----------------------------------------------------------------------------
export interface SocialLink {
  icon: string;
  label: string;
  href: string;
}

export interface FooterLink {
  name: string;
  href: string;
}

export interface FooterLinkGroup {
  title: string;
  links: FooterLink[];
}

export interface FooterContactItem {
  icon: string;
  text: string;
}

export interface FooterConfig {
  brandName: string;
  tagline: string;
  description: string;
  socialLinks: SocialLink[];
  linkGroups: FooterLinkGroup[];
  contactItems: FooterContactItem[];
  newsletterLabel: string;
  newsletterPlaceholder: string;
  newsletterButtonText: string;
  newsletterSuccessText: string;
  newsletterErrorText: string;
  newsletterEndpoint: string;
  copyrightText: string;
  legalLinks: string[];
  icpText: string;
  backToTopText: string;
  ageVerificationText: string;
}

export const footerConfig: FooterConfig = {
  brandName: "INYECTORAS",
  tagline: "Argentinas",
  description: "Más de 20 años de experiencia en inyección de plásticos y asistencia técnica integral. Servicio profesional con cobertura nacional.",
  socialLinks: [
    { icon: "Facebook", label: "Facebook", href: "https://facebook.com" },
    { icon: "Instagram", label: "Instagram", href: "https://instagram.com" },
    { icon: "Linkedin", label: "LinkedIn", href: "https://linkedin.com" },
    { icon: "Youtube", label: "YouTube", href: "https://youtube.com" }
  ],
  linkGroups: [
    {
      title: "Servicios",
      links: [
        { name: "Inyección de Plásticos", href: "#servicios" },
        { name: "Asistencia Técnica", href: "#servicios" },
        { name: "Reparación", href: "#servicios" },
        { name: "Mantenimiento", href: "#servicios" },
        { name: "Capacitación", href: "#servicios" }
      ]
    },
    {
      title: "Empresa",
      links: [
        { name: "Sobre Nosotros", href: "#nosotros" },
        { name: "Nuestro Proceso", href: "#proceso" },
        { name: "Testimonios", href: "#testimonios" },
        { name: "Contacto", href: "#contacto" }
      ]
    }
  ],
  contactItems: [
    { icon: "Phone", text: "+54 11 4567-8900" },
    { icon: "Mail", text: "info@inyectorasargentinas.com" },
    { icon: "MapPin", text: "Buenos Aires, Argentina" }
  ],
  newsletterLabel: "Suscribite a nuestro newsletter",
  newsletterPlaceholder: "tu@email.com",
  newsletterButtonText: "Suscribirme",
  newsletterSuccessText: "¡Gracias por suscribirte!",
  newsletterErrorText: "Hubo un error. Intentá nuevamente.",
  newsletterEndpoint: "https://formspree.io/f/YOUR_NEWSLETTER_ID",
  copyrightText: "© 2024 Inyectoras Argentinas. Todos los derechos reservados.",
  legalLinks: ["Política de Privacidad", "Términos de Servicio"],
  icpText: "",
  backToTopText: "Volver arriba",
  ageVerificationText: "",
};

// -----------------------------------------------------------------------------
// Scroll To Top Config
// -----------------------------------------------------------------------------
export interface ScrollToTopConfig {
  ariaLabel: string;
}

export const scrollToTopConfig: ScrollToTopConfig = {
  ariaLabel: "Volver arriba",
};

// -----------------------------------------------------------------------------
// WhatsApp Config
// -----------------------------------------------------------------------------
export interface WhatsAppConfig {
  phoneNumber: string;
  message: string;
  position: "left" | "right";
}

export const whatsAppConfig: WhatsAppConfig = {
  phoneNumber: "+5491145678900",
  message: "Hola, me gustaría solicitar información sobre sus servicios de inyección de plásticos.",
  position: "right",
};
