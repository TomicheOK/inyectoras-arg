import { MessageCircle } from 'lucide-react';
import { whatsAppConfig } from '@/config';

export function WhatsAppFloat() {
  const handleClick = () => {
    const encodedMessage = encodeURIComponent(whatsAppConfig.message);
    const whatsappUrl = `https://wa.me/${whatsAppConfig.phoneNumber}?text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <button
      onClick={handleClick}
      className="whatsapp-float"
      aria-label="Contactar por WhatsApp"
      title="Contactar por WhatsApp"
    >
      <MessageCircle className="w-8 h-8 text-white" fill="white" />
    </button>
  );
}
