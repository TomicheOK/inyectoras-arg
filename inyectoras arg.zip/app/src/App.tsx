import { useState, useCallback } from 'react';
import { Navigation } from './sections/Navigation';
import { Hero } from './sections/Hero';
import { ServicesShowcase } from './sections/ServicesShowcase';
import { ProcessCarousel } from './sections/ProcessCarousel';
import { AboutUs } from './sections/AboutUs';
import { Testimonials } from './sections/Testimonials';
import { ContactForm } from './sections/ContactForm';
import { Footer } from './sections/Footer';
import { Preloader } from './components/Preloader';
import { ScrollToTop } from './components/ScrollToTop';
import { WhatsAppFloat } from './components/WhatsAppFloat';

function App() {
  const [isLoading, setIsLoading] = useState(true);

  const handlePreloaderComplete = useCallback(() => {
    setIsLoading(false);
  }, []);

  return (
    <>
      {isLoading && <Preloader onComplete={handlePreloaderComplete} />}

      <div className={`min-h-screen bg-[#0f172a] ${isLoading ? 'overflow-hidden max-h-screen' : ''}`}>
        <Navigation />

        <main>
          <Hero isReady={!isLoading} />
          <ServicesShowcase />
          <ProcessCarousel />
          <AboutUs />
          <Testimonials />
          <ContactForm />
        </main>

        <Footer />
        <ScrollToTop />
        <WhatsAppFloat />
      </div>
    </>
  );
}

export default App;
